#include "Checkout.h"
#include <iostream>

using namespace std;
int main()
{
	Search S;
	ifstream infile;
	BookProfile BP;
	string holder;
	UserProfile U;
	Checkout C;

	infile.open("Books.txt", ios::in);
	S.initBookList(infile);

	int option = 0;

	S.SearchInput();

	cout << "would you like to add a book?" << endl;
	cout << "enter 1 for yes anything else for no" << endl;
	cin >> option;

	string bookname;
	int bookisbn = 0;
	if (option == 1)
	{
		cout << "enter book name" << endl;
		cin >> bookname;
		BP.setBookName(bookname);

		cout << "enter isbn number for book" << endl;
		cin >> bookisbn;
		BP.setBookISBN(bookisbn);
	}
	C.printBooks();

	return 0;
}